@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.csapi.org/schema/parlayx/common/v2_1")
package com.digidaroo.smsWS;
