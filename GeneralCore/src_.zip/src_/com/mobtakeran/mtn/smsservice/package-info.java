@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.csapi.org/schema/parlayx/sms/send/v2_2/local", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.mobtakeran.mtn.smsservice;
