@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.csapi.org/schema/parlayx/sms/notification/v2_2/local", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package org.csapi.schema.parlayx.sms.notification.v2_2.local;
