@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.csapi.org/schema/parlayx/sms/v2_2")
package org.csapi.schema.parlayx.sms.v2_2;
